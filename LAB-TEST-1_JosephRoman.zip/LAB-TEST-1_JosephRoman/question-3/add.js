var fs = require('fs');

var readFile = fs.readFileSync('readFile.txt', 'utf-8');
fs.writeFileSync('log0.txt', readFile);

var readFile = fs.readFileSync('readFile.txt', 'utf-8');
fs.writeFileSync('log1.txt', readFile);

var readFile = fs.readFileSync('readFile.txt', 'utf-8');
fs.writeFileSync('log2.txt', readFile);

var readFile = fs.readFileSync('readFile.txt', 'utf-8');
fs.writeFileSync('log3.txt', readFile);

var readFile = fs.readFileSync('readFile.txt', 'utf-8');
fs.writeFileSync('log4.txt', readFile);

var readFile = fs.readFileSync('readFile.txt', 'utf-8');
fs.writeFileSync('log5.txt', readFile);

var readFile = fs.readFileSync('readFile.txt', 'utf-8');
fs.writeFileSync('log6.txt', readFile);

var readFile = fs.readFileSync('readFile.txt', 'utf-8');
fs.writeFileSync('log7.txt', readFile);

var readFile = fs.readFileSync('readFile.txt', 'utf-8');
fs.writeFileSync('log8.txt', readFile);

var readFile = fs.readFileSync('readFile.txt', 'utf-8');
fs.writeFileSync('log9.txt', readFile);




