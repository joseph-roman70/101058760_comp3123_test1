var fs = require('fs');

var path = './log0.txt'

fs.unlink(path, (err) => {
    if (err) {
        console.error(err)
        return
    }
})

var path1 = './log1.txt'

fs.unlink(path1, (err) => {
    if (err) {
        console.error(err)
        return
    }
})

var path2 = './log2.txt'

fs.unlink(path2, (err) => {
    if (err) {
        console.error(err)
        return
    }
})

var path3 = './log3.txt'

fs.unlink(path3, (err) => {
    if (err) {
        console.error(err)
        return
    }
})

var path4 = './log4.txt'

fs.unlink(path4, (err) => {
    if (err) {
        console.error(err)
        return
    }
})

var path5 = './log5.txt'

fs.unlink(path5, (err) => {
    if (err) {
        console.error(err)
        return
    }
})

var path6 = './log6.txt'

fs.unlink(path6, (err) => {
    if (err) {
        console.error(err)
        return
    }
})

var path7 = './log7.txt'

fs.unlink(path7, (err) => {
    if (err) {
        console.error(err)
        return
    }
})

var path8 = './log8.txt'

fs.unlink(path8, (err) => {
    if (err) {
        console.error(err)
        return
    }
})

var path9 = './log9.txt'

fs.unlink(path9, (err) => {
    if (err) {
        console.error(err)
        return
    }
})